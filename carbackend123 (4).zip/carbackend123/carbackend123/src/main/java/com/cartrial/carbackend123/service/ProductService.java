package com.cartrial.carbackend123.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.cartrial.carbackend123.model.Product;
import com.cartrial.carbackend123.model.dao.ProductDAO;

/**
 * Service for handling product actions.
 */
@Service
public class ProductService {

  /** The Product DAO. */
  private ProductDAO productDAO;

  /**
   * Constructor for spring injection.
   * @param productDAO
   */
  public ProductService(ProductDAO productDAO) {
    this.productDAO = productDAO;
  }

  /**
   * Gets the all products available.
   * @return The list of products.
   */
  public List<Product> getProducts() {
    return productDAO.findAll();
  }

}