package com.cartrial.carbackend123.model.dao;

import org.springframework.data.repository.ListCrudRepository;

import com.cartrial.carbackend123.model.Product;

public interface ProductDAO extends ListCrudRepository<Product, Long> {
}