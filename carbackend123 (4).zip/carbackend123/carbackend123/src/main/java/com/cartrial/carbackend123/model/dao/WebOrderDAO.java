package com.cartrial.carbackend123.model.dao;

import java.util.List;

import org.springframework.data.repository.ListCrudRepository;

import com.cartrial.carbackend123.model.LocalUser;
import com.cartrial.carbackend123.model.WebOrder;

/**
 * Data Access Object to access WebOrder data.
 */
public interface WebOrderDAO extends ListCrudRepository<WebOrder, Long> {
	List<WebOrder> findByUser(LocalUser user);

}