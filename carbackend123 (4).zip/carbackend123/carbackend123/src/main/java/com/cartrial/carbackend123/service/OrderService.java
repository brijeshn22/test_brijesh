package com.cartrial.carbackend123.service;

import java.util.List;

import com.cartrial.carbackend123.model.LocalUser;
import com.cartrial.carbackend123.model.WebOrder;
import com.cartrial.carbackend123.model.dao.WebOrderDAO;
import org.springframework.stereotype.Service;

/**
 * Service for handling order actions.
 */
@Service
public class OrderService {

  /** The Web Order DAO. */
  private WebOrderDAO webOrderDAO;

  /**
   * Constructor for spring injection.
   * @param webOrderDAO
   */
  public OrderService(WebOrderDAO webOrderDAO) {
    this.webOrderDAO = webOrderDAO;
  }

  /**
   * Gets the list of orders for a given user.
   * @param user The user to search for.
   * @return The list of orders.
   */
  public List<WebOrder> getOrders(LocalUser user) {
    return webOrderDAO.findByUser(user);
  }

}