package com.cartrial.carbackend123.exception;

/**
 * Exception thrown at user registration if an existing user already exists
 * with the given information.
 */
//@SuppressWarnings("serial")
public class UserAlreadyExistsException extends Exception {
}